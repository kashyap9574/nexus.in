/**
 * Nexus Fresh Export — enquiry inbox
 * Free backend. No server, no hosting cost. Data lives in a Google Sheet.
 *
 * SETUP (5 minutes, once)
 * 1. Go to sheets.new and make a blank sheet. Name it "Nexus Enquiries".
 * 2. Extensions > Apps Script. Delete whatever is there.
 * 3. Paste this whole file in.
 * 4. Change SECRET below to your own password. Anything you like, keep it private.
 * 5. Deploy > New deployment > type "Web app".
 *      Execute as:        Me
 *      Who has access:    Anyone
 *    Click Deploy, allow the permissions it asks for.
 * 6. Copy the Web app URL it gives you. It looks like
 *      https://script.google.com/macros/s/AKfy..../exec
 * 7. Paste that URL into two places:
 *      - nexus-fresh-export.html   -> the ENDPOINT line near the top of <script>
 *      - nexus-admin.html          -> the sign-in screen, along with your SECRET
 *
 * If you ever change this code, use Deploy > Manage deployments > edit > New version,
 * otherwise the old version keeps running.
 */

var SECRET     = 'change-this-to-your-own-password';
var SHEET_NAME = 'Enquiries';

var HEADERS = ['id','received','name','company','country','phone','product',
               'size','quantity','port','notes','via','status','internal_notes'];

function doPost(e) {
  try {
    var body = JSON.parse((e && e.postData && e.postData.contents) || '{}');

    // anyone may submit an enquiry
    if (body.action === 'submit') return json(submitEnquiry(body.data || {}));

    // everything else needs the key
    if (body.key !== SECRET) return json({ ok: false, error: 'Wrong key' });

    if (body.action === 'list')   return json({ ok: true, rows: listEnquiries() });
    if (body.action === 'update') return json(updateEnquiry(body.id, body.status, body.internal_notes));
    if (body.action === 'delete') return json(deleteEnquiry(body.id));

    return json({ ok: false, error: 'Unknown action' });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}

function doGet() {
  return json({ ok: true, service: 'Nexus Fresh Export enquiry inbox' });
}

function getSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.appendRow(HEADERS);
    sh.getRange(1, 1, 1, HEADERS.length).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

function submitEnquiry(d) {
  var sh = getSheet();
  var id = 'NFE-' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyMMdd') + '-' +
           Math.random().toString(36).slice(2, 6).toUpperCase();

  sh.appendRow([
    id,
    new Date(),
    d.name || '', d.company || '', d.country || '', d.phone || '',
    d.product || '', d.size || '', d.quantity || '', d.port || '',
    d.notes || '', d.via || '',
    'New', ''
  ]);

  notify(id, d);
  return { ok: true, id: id };
}

/** Optional: emails you the moment an enquiry lands. Set to '' to switch off. */
function notify(id, d) {
  var to = 'info@nexusfreshexport.in';
  if (!to) return;
  try {
    MailApp.sendEmail({
      to: to,
      subject: 'New enquiry ' + id + ' — ' + (d.name || 'unknown') + ', ' + (d.country || ''),
      body: [
        'Name: '     + (d.name     || '-'),
        'Company: '  + (d.company  || '-'),
        'Country: '  + (d.country  || '-'),
        'Phone: '    + (d.phone    || '-'),
        'Product: '  + (d.product  || '-'),
        'Size: '     + (d.size     || '-'),
        'Quantity: ' + (d.quantity || '-'),
        'Port: '     + (d.port     || '-'),
        'Notes: '    + (d.notes    || '-')
      ].join('\n')
    });
  } catch (err) { /* quota reached or mail off — the row is still saved */ }
}

function listEnquiries() {
  var sh = getSheet();
  var last = sh.getLastRow();
  if (last < 2) return [];

  var values = sh.getRange(2, 1, last - 1, HEADERS.length).getValues();
  return values.map(function (r) {
    var o = {};
    HEADERS.forEach(function (h, i) { o[h] = r[i]; });
    o.received = r[1] instanceof Date ? r[1].toISOString() : String(r[1] || '');
    return o;
  }).reverse();                       // newest first
}

function findRow(sh, id) {
  var ids = sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 1), 1).getValues();
  for (var i = 0; i < ids.length; i++) if (String(ids[i][0]) === String(id)) return i + 2;
  return 0;
}

function updateEnquiry(id, status, internalNotes) {
  var sh = getSheet();
  var row = findRow(sh, id);
  if (!row) return { ok: false, error: 'Enquiry not found' };
  if (status !== undefined && status !== null) sh.getRange(row, 13).setValue(status);
  if (internalNotes !== undefined && internalNotes !== null) sh.getRange(row, 14).setValue(internalNotes);
  return { ok: true };
}

function deleteEnquiry(id) {
  var sh = getSheet();
  var row = findRow(sh, id);
  if (!row) return { ok: false, error: 'Enquiry not found' };
  sh.deleteRow(row);
  return { ok: true };
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
                       .setMimeType(ContentService.MimeType.JSON);
}
